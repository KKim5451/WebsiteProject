$(document).ready(function() { //Slick function
    $('.articles').slick({
      centerMode: true,
      centerPadding: '60px',
      slidesToShow: 3,
      fade: false,
      });
});